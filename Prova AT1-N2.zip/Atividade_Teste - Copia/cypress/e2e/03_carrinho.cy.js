describe('Funcionalidade: Carrinho de Compras', () => {

  // Bloco que executa antes de cada teste
  beforeEach(() => {
    // Realiza o login para poder interagir com os produtos
    cy.login('standard_user', 'secret_sauce');
  });

  it('Deve adicionar um produto ao carrinho com sucesso', () => {
    // Encontra um produto específico pelo nome e, dentro dele, acha e clica no botão "ADD TO CART"
    cy.get('.inventory_item').contains('Sauce Labs Fleece Jacket').parent().parent().find('button').click();

    // Valida se o ícone do carrinho no canto superior direito agora mostra o número "1"
    cy.get('.shopping_cart_badge').should('have.text', '1');
  });

  it('Deve remover um produto do carrinho', () => {
    // PASSO 1: Adicionar um produto para poder remover depois
    cy.get('.inventory_item').contains('Sauce Labs Bolt T-Shirt').parent().parent().find('button').click();
    cy.get('.shopping_cart_badge').should('have.text', '1'); // Confirma que adicionou

    // PASSO 2: Ir para a página do carrinho
    cy.get('.shopping_cart_link').click();
    cy.url().should('include', '/cart.html'); // Valida se está na página correta

    // PASSO 3: Remover o produto
    cy.get('.cart_item').contains('Sauce Labs Bolt T-Shirt').parent().parent().find('button').click();

    // PASSO 4: Validar que o carrinho ficou vazio
    cy.get('.shopping_cart_badge').should('not.exist'); // O ícone com o número deve sumir
    cy.get('.removed_cart_item').should('exist'); // Confirma que o item foi para o estado "removido"
  });

});