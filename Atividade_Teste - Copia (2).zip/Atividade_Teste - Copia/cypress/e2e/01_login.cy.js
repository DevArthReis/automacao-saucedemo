describe('Funcionalidade: Login e Logout', () => {

  it('Deve realizar login com sucesso', () => {
    cy.login('standard_user', 'secret_sauce');
    cy.url().should('include', '/inventory.html'); // Valida se está na página de produtos
    cy.get('.product_label').should('be.visible');
  });

  it('Deve falhar ao tentar logar com usuário bloqueado', () => {
    cy.login('locked_out_user', 'secret_sauce');
    cy.get('[data-test="error"]').should('have.text', 'Epic sadface: Sorry, this user has been locked out.');
  });
  
  it('Deve realizar logout com sucesso', () => {
  // 1. Faz o login para chegar na página de produtos
  cy.login('standard_user', 'secret_sauce');

  // 2. Clica no botão do menu para abrir a sidebar
  cy.get('.bm-burger-button > button');

  // 3. Clica no link de logout que agora está visível
  cy.get('#logout_sidebar_link').click({ force: true });

  // 4. Valida se voltou para a tela de login
  cy.url().should('not.include', '/inventory.html');
  cy.get('#login-button').should('be.visible');
});
});